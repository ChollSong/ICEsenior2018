from subprocess import PIPE,Popen
import os
import time
import sys
import json



filePathList = ["G:\\APK\\#1-100","G:\\APK\\#101-200","G:\\APK\\#201-300","G:\\APK\\#301-400","G:\\APK\\#401-500"]
aaptPath = 'C:\\AndroidSDK\\build-tools\\27.0.3\\aapt.exe'
key = 0
data=[]

for path in filePathList:
    appList = os.listdir(path)
    for apkFile in appList:
        p = Popen([aaptPath,'d','permissions',path+'\\'+apkFile],shell=False,stderr=PIPE,stdout=PIPE)
        package = "Err Package"
        usesPermission = []
        permission = []
        while True:
            readline = ""
            line = p.stdout.readline()
            if (line != '' and line != None):
                #read line
                readline = line.rstrip()
                #is package
                if(readline.find('package:')!=-1):
                    package = readline[9:len(readline)]
                elif (readline.find('uses-permission:')!=-1):
                    usesPermission.append(readline[23:len(readline)-1])
                elif(readline.find('permission:')!=-1):
                    permission.append(readline[12:len(readline)])
            else:
                dictData = {key: {'package':package,'uses-permission': usesPermission, 'permission':permission}}
                data.append(dictData)
                #add data to json file
                key = key+1
                break
        p.kill()

with open('Permissions.json', 'w') as f:
    f.write(json.dumps({'data':data}))
    f.close()
print('extract done')
        
       
        

        
