import re
import json

#might implement later on
macAddress = ''
email = 'johndoecena'
#number registered with the phone
phoneNumber = ''

def searchBody(body):
    m = re.search('IMEI|MAC|Password|password|Email|email|credit|Credit|email|Email|Phone|phone|jdcburner|burnerice2018', body)
    if(m != None):
        return 1
    else:
        return 0



searchBody("blahblahjdcbuerspacethefinalfrontierPhone")

"""



phone & number
IMEI
MAC
Password
Email
passport
credit
"""