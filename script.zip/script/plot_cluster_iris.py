#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
=========================================================
K-means Clustering
=========================================================

The plots display firstly what a K-means algorithm would yield
using three clusters. It is then shown what the effect of a bad
initialization is on the classification process:
By setting n_init to only 1 (default is 10), the amount of
times that the algorithm will be run with different centroid
seeds is reduced.
The next plot displays what using eight clusters would deliver
and finally the ground truth.

"""
print(__doc__)


# Code source: Gaël Varoquaux
# Modified for documentation by Jaques Grobler
# License: BSD 3 clause


import matplotlib.pyplot as plt
plt.rcParams['backend'] = "Qt4Agg"

import numpy as np
# Though the following import is not directly being used, it is required
# for 3D projection to work
from mpl_toolkits.mplot3d import Axes3D
from sklearn import preprocessing
from sklearn import datasets
from sklearn.cluster import KMeans
from sklearn.cluster import AgglomerativeClustering
import time
import pandas as pd
from scipy.cluster.hierarchy import dendrogram, linkage


input_file = "cleaned_cluster_noBit.csv"
plt.style.use('ggplot')

session = pd.read_csv(input_file)

Xtemp = np.array(session)
X = Xtemp[:,1:]
X = X.astype(np.float64)
#print(X)
print(len(X))
X = preprocessing.MinMaxScaler(copy=True, feature_range=(0, 10)).fit_transform(X)
#X = preprocessing.scale(X)

#aggloMeans = AgglomerativeClustering(n_clusters=5,affinity='euclidean',linkage='ward')
kmeans = KMeans(n_clusters=4, random_state=0).fit_predict(X)

df = pd.DataFrame(kmeans, columns=["apps"])
#df.to_csv('list.csv', index=False)

print kmeans

#print kmeans.labels_
#print "center cluster is: "
#print kmeans.cluster_centers_
#print(np_array)

# Create a kmeans model on our data, using 2 clusters.  random_state helps ensure that the algorithm returns the same results each time.
#need to plot in order to determin how many clusters
#one line nigga
#clusteringModel = AgglomerativeClustering(n_clusters=2).fit(np_array)

# These are our fitted labels for clusters -- the first cluster has label 0, and the second has label 1.
Z = linkage(X, 'ward')

# The clustering looks pretty good!
# It's separated everyone into parties just based on voting history
# calculate full dendrogram
plt.title('Hierarchical Clustering Dendrogram')
plt.xlabel('sample index')
plt.ylabel('distance')
dendrogram(
    Z,
    truncate_mode='lastp',
    leaf_rotation=90.,  # rotates the x axis labels
    leaf_font_size=8.,  # font size for the x axis labels
)
plt.show()


